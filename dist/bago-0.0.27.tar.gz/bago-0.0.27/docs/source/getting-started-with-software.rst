With A Windows App
-----------------------

.. meta::
   :description lang=en: Get started optimizing LC gradient with a Windows Application.

A Windows Application is provided to help you get started with the LC gradient optimization. 
The Window App is available on Google Drive. 

Quick start
~~~~~~~~~~~

Download the ``BAGO.exe`` file from `Google Drive <https://drive.google.com/drive/folders/1_ZIRb1Az9rDR2BejPNXmKnhhMWWS4hXO?usp=sharing>`_.

Follow the instructions in the PDF file to start.