# BAGO

A Bayeian optimization framework for designing gradient elution in LC-MS experiments.